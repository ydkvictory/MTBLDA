
import torch

###MTBLDA
def train(model, train_data, optimizer, opt):
    model.train()  #模型改为训练模式

    for epoch in range(0, opt.epoch):
        model.zero_grad()  #梯度清零
        score,x,y = model(train_data)  #传入train_data,得到score,x,y
        loss = torch.nn.BCEWithLogitsLoss(reduction='mean') #定义二元交叉熵为损失函数
        loss = loss(score, train_data['l_d'].cuda())  
            # 反向传播
        loss.backward()
        optimizer.step()
        print(loss.item())
    score = score.detach().cpu().numpy()
    return model


# ###MTBLDA_case_study
# def train(model, train_data, optimizer, opt):
#     model.eval()
#     with torch.no_grad():
#         # 假设 test_data 是你的测试数据，包含输入特征
#
#         score, x, y = model(train_data)
#
#     return model