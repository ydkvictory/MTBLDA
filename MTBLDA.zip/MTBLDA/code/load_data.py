import csv
import torch
import random
from train import train
import numpy as np
import math
from scipy.io import loadmat


def  _getDS_integration(opt, nd):
    ####dataset1
    DS = read_csv(opt.dataset_path + '/DSS.csv')  #dataset1
    KD = read_csv(opt.dataset_path + '/DGS.csv')  #疾病高斯相似度
    ####

    # ###dataset2
    # DS = read_csv(opt.dataset_path + '/disease-disease.csv')  #dataset2
    # KD_1 = loadmat(opt.dataset_path+'/GSD.mat')
    # KD = torch.tensor(KD_1['diease_gsSim'], dtype=torch.float32)
    # ###

    DS_integration = np.zeros((nd, nd))
    for i in range(nd):   #融合两个相似度
        for j in range(nd):
            if DS[i, j] > 0:
                DS_integration[i, j] = DS[i, j]        #大于0(即语义上有关联)用语义相似度
            else:
                DS_integration[i, j] = KD[i, j]        #等于0(即语义上无关联)用高斯相似度
    return torch.FloatTensor(DS_integration)


# 整合LncRNA相似性特征
def _getFS_integration(opt, nm):
    ####dataset1
    FS = read_csv(opt.dataset_path + '/LFS.csv') #读取Lncrna的功能相似性矩阵   #dataset1
    KM = read_csv(opt.dataset_path + '/LGS.csv')
    ####

    # ###dataset2
    # FS = read_csv(opt.dataset_path + '/lncRNA-lncRNA.csv')  #dataset2
    # KM_1 = loadmat(opt.dataset_path + '/GSL.mat')
    # KM = torch.tensor(KM_1['lncrna_gsSim'], dtype=torch.float32)
    # ###

    FS_integration = np.zeros((nm, nm))
    for i in range(nm):
        for j in range(nm):  #依次读取fs矩阵,有相似性的不变,没有相似性的将0替换为高斯相似性
            if FS[i, j] > 0:
                FS_integration[i, j] = FS[i, j]
            else:
                FS_integration[i, j] = KM[i, j]
    return torch.FloatTensor(FS_integration)




def read_csv(path):
    with open(path, 'r', newline='') as csv_file:
        reader = csv.reader(csv_file)
        md_data = []
        md_data += [[float(i) for i in row] for row in reader]
        return torch.Tensor(md_data)


def get_edge_index(matrix):
    edge_index = [[], []]
    for i in range(matrix.size(0)):
        for j in range(matrix.size(1)):
            if matrix[i][j] != 0:
                edge_index[0].append(i)
                edge_index[1].append(j)
    return torch.LongTensor(edge_index)


def generate_combined_adj(adj, mm, dd, T):  # 将
    # T is the threshold for similarity matrices
    nm = mm.shape[0]
    nd = dd.shape[0]
    md_adj = np.zeros((nm + nd, nm + nd))
    for i in range(adj.shape[0]):  # i for LncRNA
        for j in range(adj.shape[1]):  # j for disease
            if adj[i][j] > 0:
                md_adj[i][j + nm] = 1
                md_adj[j + nm][i] = 1

    for i in range(nm):
        for j in range(nm):
            if mm[i][j] >= T:
                md_adj[i][j] = mm[i][j]
                md_adj[j][i] = mm[i][j]
    for i in range(nd):
        for j in range(nd):
            if dd[i][j] >= T:
                md_adj[i + nm][j + nm] = dd[i][j]
                md_adj[i + nm][j + nm] = dd[i][j]

    # 去掉自环
    for i in range(nm + nd):
        md_adj[i][i] = 0

    return torch.FloatTensor(md_adj)

###dataset1
def dataset(args):
    dataset = dict()  # 定义数据集为字典

    dataset['l_d'] = read_csv(args.dataset_path + '/LDA.csv')  # 读取已知l-d关联矩阵赋给dataset['l_d']  #数据集1:/LDA.csv  数据集2:/DLA.csv

    # DLA = read_csv(args.dataset_path + '/disease-lncRNA.csv')
    # dataset['l_d'] = DLA.t()

    zero_index = []
    one_index = []
    ld_pairs = []
    for i in range(dataset['l_d'].size(0)):
        for j in range(dataset['l_d'].size(1)):
            if dataset['l_d'][i][j] < 1:
                zero_index.append([i, j, 0])
            if dataset['l_d'][i][j] >= 1:
                one_index.append([i, j, 1])

    ld_pairs = random.sample(zero_index,len(one_index)) + one_index


    # 通过lncrna和disease的已知关联矩阵得到二者的初始特征
    LDA = read_csv(args.dataset_path + '/LDA.csv')
    dataset['lnc_ori']=LDA.mm(LDA.t())
    dataset['dis_ori'] = (LDA.t()).mm(LDA)

    # dataset['lnc_ori'] = (DLA.t()).mm(DLA)
    # dataset['dis_ori'] = DLA.mm(DLA.t())


    # 通过disease和Lncrna的邻接矩阵和相似度矩阵分别得到二者的图的邻接矩阵
    dd_matrix = _getDS_integration(args , 412)  #dataset1=412,dataset2=218
    dd_edge_index = get_edge_index(dd_matrix)
    dataset['dd'] = {'data_matrix': dd_matrix, 'edges': dd_edge_index}

    ll_matrix = _getFS_integration(args , 240) #dataset1=240,dataset2=447
    ll_edge_index = get_edge_index(ll_matrix)
    dataset['ll'] = {'data_matrix': ll_matrix, 'edges': ll_edge_index}

    l_struct_matrix = read_csv(args.dataset_path + '/LCS.csv')
    print(l_struct_matrix.shape)
    ls_edge_index = get_edge_index(l_struct_matrix)
    dataset['ls'] = {'data_matrix': l_struct_matrix, 'edges': ls_edge_index}

    d_struct_matrix = read_csv(args.dataset_path + '/DCS.csv')
    ds_edge_index = get_edge_index(d_struct_matrix)
    dataset['ds'] = {'data_matrix': d_struct_matrix, 'edges': ds_edge_index}


    # 通过disease和Lncrna的邻接矩阵和相似度矩阵组成l-d异构图的相似度矩阵以及l-d异构图的邻接矩阵
    ld_matrix = generate_combined_adj(dataset['l_d'], ll_matrix, dd_matrix, 0)
    ld_edge_index = get_edge_index(ld_matrix)
    dataset['ld'] = {'data_matrix': ld_matrix, 'edges': ld_edge_index}

    # l_struct_matrix_1 = loadmat(args.dataset_path + '/CosL.mat')
    # l_struct_matrix = torch.tensor(l_struct_matrix_1['CosL'], dtype=torch.float32)
    # ls_edge_index = get_edge_index(l_struct_matrix)
    # dataset['ls'] = {'data_matrix': l_struct_matrix, 'edges': ls_edge_index}
    #
    # d_struct_matrix_1 = loadmat(args.dataset_path + '/CosD.mat')
    # d_struct_matrix = torch.tensor(d_struct_matrix_1['CosD'], dtype=torch.float32)
    # ds_edge_index = get_edge_index(d_struct_matrix)
    # dataset['ds'] = {'data_matrix': d_struct_matrix, 'edges': ds_edge_index}
    #
    #
    # # 通过disease和mirna的邻接矩阵和相似度矩阵组成m-d异构图的相似度矩阵以及m-d异构图的邻接矩阵
    # ld_matrix = generate_combined_adj(dataset['l_d'], ll_matrix, dd_matrix, 0.2)
    # ld_edge_index = get_edge_index(ld_matrix)
    # dataset['ld'] = {'data_matrix': ld_matrix, 'edges': ld_edge_index}

    return dataset, ld_pairs
###

# ###dataset2
# def dataset(args):
#     dataset = dict()
#
#     dataset['d_l'] = read_csv(args.dataset_path + '/disease-lncRNA.csv')  # 读取已知l-d关联矩阵赋给dataset['c_d']  #数据集1:/LDA.csv  数据集2:/DLA.csv
#     dataset['l_d'] = dataset['d_l'].t()
#     # DLA = read_csv(args.dataset_path + '/disease-lncRNA.csv')
#     # dataset['l_d'] = DLA.t()
#
#     zero_index = []
#     one_index = []
#     ld_pairs = []
#     for i in range(dataset['l_d'].size(0)):
#         for j in range(dataset['l_d'].size(1)):
#             if dataset['l_d'][i][j] < 1:
#                 zero_index.append([i, j, 0])
#             if dataset['l_d'][i][j] >= 1:
#                 one_index.append([i, j, 1])
#
#     ld_pairs = random.sample(zero_index,len(one_index)) + one_index
#
#
#     # 通过lncrna和disease的已知关联矩阵得到二者的初始特征
#     LDA = dataset['l_d']
#     dataset['lnc_ori']=LDA.mm(LDA.t())
#     dataset['dis_ori'] = (LDA.t()).mm(LDA)
#
#     # dataset['lnc_ori'] = (DLA.t()).mm(DLA)
#     # dataset['dis_ori'] = DLA.mm(DLA.t())
#
#
#     # 通过disease和Lncrna的邻接矩阵和相似度矩阵分别得到二者的邻接矩阵
#     dd_matrix = _getDS_integration(args , 218)  #dataset1=412,dataset2=218
#     # H_dis = hypergraph_construct(dd_matrix, args.k_neig, is_probH=True, m_prob=1)
#     dd_edge_index = get_edge_index(dd_matrix)
#     dataset['dd'] = {'data_matrix': dd_matrix, 'edges': dd_edge_index}
#
#     ll_matrix = _getFS_integration(args , 447) #dataset1=240,dataset2=447
#     # H_mir = hypergraph_construct(ll_matrix, args.k_neig, is_probH=True, m_prob=1)
#     ll_edge_index = get_edge_index(ll_matrix)
#     dataset['ll'] = {'data_matrix': ll_matrix, 'edges': ll_edge_index}
#
#     # l_struct_matrix = read_csv(args.dataset_path + '/LCS.csv')
#     # print(l_struct_matrix.shape)
#     # ls_edge_index = get_edge_index(l_struct_matrix)
#     # dataset['ls'] = {'data_matrix': l_struct_matrix, 'edges': ls_edge_index}
#     #
#     # d_struct_matrix = read_csv(args.dataset_path + '/DCS.csv')
#     # ds_edge_index = get_edge_index(d_struct_matrix)
#     # dataset['ds'] = {'data_matrix': d_struct_matrix, 'edges': ds_edge_index}
#
#
#     # # 通过disease和Lncrna的邻接矩阵和相似度矩阵组成l-d异构图的相似度矩阵以及l-d异构图的邻接矩阵
#     # ld_matrix = generate_combined_adj(dataset['l_d'], ll_matrix, dd_matrix, 0)
#     # ld_edge_index = get_edge_index(ld_matrix)
#     # dataset['ld'] = {'data_matrix': ld_matrix, 'edges': ld_edge_index}
#
#     l_struct_matrix_1 = loadmat(args.dataset_path + '/CosL.mat')
#     l_struct_matrix = torch.tensor(l_struct_matrix_1['CosL'], dtype=torch.float32)
#     ls_edge_index = get_edge_index(l_struct_matrix)
#     dataset['ls'] = {'data_matrix': l_struct_matrix, 'edges': ls_edge_index}
#
#     d_struct_matrix_1 = loadmat(args.dataset_path + '/CosD.mat')
#     d_struct_matrix = torch.tensor(d_struct_matrix_1['CosD'], dtype=torch.float32)
#     ds_edge_index = get_edge_index(d_struct_matrix)
#     dataset['ds'] = {'data_matrix': d_struct_matrix, 'edges': ds_edge_index}
#
#
#     # 通过disease和Lncrna的邻接矩阵和相似度矩阵组成l-d异构图的相似度矩阵以及l-d异构图的邻接矩阵
#     ld_matrix = generate_combined_adj(dataset['l_d'], ll_matrix, dd_matrix, 0)
#     ld_edge_index = get_edge_index(ld_matrix)
#     dataset['ld'] = {'data_matrix': ld_matrix, 'edges': ld_edge_index}
#
#     return dataset, ld_pairs
# ###


# ###dataset_case
# def dataset(args):
#     dataset = dict()
#
#     #dataset['l_d'] = read_csv(args.dataset_path + '/LDA.csv')
#     dataset['l_d'] = read_csv(args.dataset_path + '/lncRNA-disease-case_study.csv')  # 读取已知l-d关联矩阵赋给dataset['c_d']  #数据集1:/LDA.csv  数据集2:/DLA.csv
#
#
#     # DLA = read_csv(args.dataset_path + '/disease-lncRNA.csv')
#     # dataset['l_d'] = DLA.t()
#
#     zero_index = []
#     one_index = []
#     ld_pairs = []
#     for i in range(dataset['l_d'].size(0)):
#         for j in range(dataset['l_d'].size(1)):
#             if dataset['l_d'][i][j] < 1:
#                 zero_index.append([i, j, 0])
#             if dataset['l_d'][i][j] >= 1:
#                 one_index.append([i, j, 1])
#
#     ld_pairs = zero_index + one_index
#
#
#     # 通过lncrna和disease的已知关联矩阵得到二者的初始特征
#     #LDA = read_csv(args.dataset_path + '/LDA.csv')
#     LDA = read_csv(args.dataset_path + '/lncRNA-disease-case_study.csv')
#     dataset['lnc_ori']=LDA.mm(LDA.t())
#     dataset['dis_ori'] = (LDA.t()).mm(LDA)
#
#     # dataset['lnc_ori'] = (DLA.t()).mm(DLA)
#     # dataset['dis_ori'] = DLA.mm(DLA.t())
#
#
#     # 通过disease和Lncrna的邻接矩阵和相似度矩阵分别得到二者的图的邻接矩阵
#     dd_matrix = _getDS_integration(args , 412)  #dataset1=412,dataset2=218
#     H_dis = hypergraph_construct(dd_matrix, args.k_neig, is_probH=True, m_prob=1)
#     dd_edge_index = get_edge_index(H_dis)
#     dataset['dd'] = {'data_matrix': dd_matrix, 'edges': dd_edge_index}
#
#     ll_matrix = _getFS_integration(args , 240) #dataset1=240,dataset2=447
#     H_mir = hypergraph_construct(ll_matrix, args.k_neig, is_probH=True, m_prob=1)
#     ll_edge_index = get_edge_index(H_mir)
#     dataset['ll'] = {'data_matrix': ll_matrix, 'edges': ll_edge_index}
#
#     l_struct_matrix = read_csv(args.dataset_path + '/LCS.csv')
#     print(l_struct_matrix.shape)
#     ls_edge_index = get_edge_index(l_struct_matrix)
#     dataset['ls'] = {'data_matrix': l_struct_matrix, 'edges': ls_edge_index}
#
#     d_struct_matrix = read_csv(args.dataset_path + '/DCS.csv')
#     ds_edge_index = get_edge_index(d_struct_matrix)
#     dataset['ds'] = {'data_matrix': d_struct_matrix, 'edges': ds_edge_index}
#
#
#     # 通过disease和Lncrna的邻接矩阵和相似度矩阵组成l-d异构图的相似度矩阵以及l-d异构图的邻接矩阵
#     ld_matrix = generate_combined_adj(dataset['l_d'], ll_matrix, dd_matrix, 0)
#     ld_edge_index = get_edge_index(ld_matrix)
#     dataset['ld'] = {'data_matrix': ld_matrix, 'edges': ld_edge_index}
#
#     # l_struct_matrix_1 = loadmat(args.dataset_path + '/CosL.mat')
#     # l_struct_matrix = torch.tensor(l_struct_matrix_1['CosL'], dtype=torch.float32)
#     # ls_edge_index = get_edge_index(l_struct_matrix)
#     # dataset['ls'] = {'data_matrix': l_struct_matrix, 'edges': ls_edge_index}
#     #
#     # d_struct_matrix_1 = loadmat(args.dataset_path + '/CosD.mat')
#     # d_struct_matrix = torch.tensor(d_struct_matrix_1['CosD'], dtype=torch.float32)
#     # ds_edge_index = get_edge_index(d_struct_matrix)
#     # dataset['ds'] = {'data_matrix': d_struct_matrix, 'edges': ds_edge_index}
#     #
#     #
#     # # 通过disease和Lncrna的邻接矩阵和相似度矩阵组成l-d异构图的相似度矩阵以及l-d异构图的邻接矩阵
#     # ld_matrix = generate_combined_adj(dataset['l_d'], ll_matrix, dd_matrix, 0.2)
#     # ld_edge_index = get_edge_index(ld_matrix)
#     # dataset['ld'] = {'data_matrix': ld_matrix, 'edges': ld_edge_index}
#
#     return dataset, ld_pairs
# ###








def feature_representation(model, args, dataset):
    model.cuda() #把模型放在cuda上

    optimizer = torch.optim.Adam(model.parameters(), lr=0.0001)
    model = train(model, dataset, optimizer, args)  #训练模型

    with torch.no_grad():
        score, lnc_fea, dis_fea = model(dataset)
    lnc_fea = lnc_fea.cpu().detach().numpy()
    dis_fea = dis_fea.cpu().detach().numpy()
    return score, lnc_fea, dis_fea


def new_dataset(lnc_fea, dis_fea, ld_pairs):
    unknown_pairs = []
    known_pairs = []
    
    for pair in ld_pairs:
        if pair[2] == 1:
            known_pairs.append(pair[:2])
            
        if pair[2] == 0:
            unknown_pairs.append(pair[:2])
    
    
    
    print("--------------------")
    print(lnc_fea.shape,dis_fea.shape)
    print("--------------------")
    print(len(unknown_pairs), len(known_pairs))
    
    nega_list = []
    for i in range(len(unknown_pairs)):
        nega = lnc_fea[unknown_pairs[i][0],:].tolist() + dis_fea[unknown_pairs[i][1],:].tolist()+[0,1]
        nega_list.append(nega)
        
    posi_list = []
    for j in range(len(known_pairs)):
        posi = lnc_fea[known_pairs[j][0],:].tolist() + dis_fea[known_pairs[j][1],:].tolist()+[1,0]
        posi_list.append(posi)
    
    samples = posi_list + nega_list
    
    random.shuffle(samples)
    samples = np.array(samples)
    return samples

def L_Dmatix(ld_pairs,trainindex,testindex):
    l_dmatix = np.zeros((240,412))
    for i in trainindex:
        if ld_pairs[i][2]==1:
            l_dmatix[ld_pairs[i][0]][ld_pairs[i][1]]=1


    
    dataset = dict()
    ld_data = []
    ld_data += [[float(i) for i in row] for row in l_dmatix]
    ld_data = torch.Tensor(ld_data)
    dataset['l_d'] = ld_data
    
    train_ld_pairs = []
    test_ld_pairs = []
    for m in trainindex:
        train_ld_pairs.append(ld_pairs[m])
    
    for n in testindex:
        test_ld_pairs.append(ld_pairs[n])



    return dataset['l_d'],train_ld_pairs,test_ld_pairs #返回转化为张量的矩阵,该矩阵仅有这一折的训练集数据中的正样本,返回得到这一折的训练样本和测试样本