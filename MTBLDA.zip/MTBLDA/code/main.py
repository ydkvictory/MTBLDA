from numpy import interp
from param import parameter_parser
import torch
import load_data
from model import MTBLDA
from sklearn.model_selection import KFold
import evaluation_scores

from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn import svm
from sklearn.ensemble import GradientBoostingClassifier

import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc, precision_recall_curve, average_precision_score
import time
import numpy as np
import pandas as pd
 


def  LDA(n_fold):
    args = parameter_parser()
    dataset, ld_pairs = load_data.dataset(args)
 
    
    kf = KFold(n_splits = n_fold, shuffle = True)  #k折划分方法声明
    model = MTBLDA(args)  #创建主体模型
    
    ave_acc = 0
    ave_prec = 0
    ave_sens = 0
    ave_f1_score = 0
    ave_mcc = 0
    ave_auc = 0
    ave_auprc = 0

    mean_fpr = np.linspace(0, 1, 100)
    mean_recall = np.linspace(0, 1, 100)
    tprs_list = []
    precisions_list = []
    average_precisions = []
    aucs = []
    score1 = 0
    fig, axs = plt.subplots(1, 2, figsize=(12, 6))

    localtime = time.asctime( time.localtime(time.time()) )
    with open('E:/project/AACODE/ceshi/result/GraphCDA-100--5fold.txt', 'a') as f:
        f.write('time:\t'+ str(localtime)+"\n")

        
        for train_index, test_index in kf.split(ld_pairs):  #将平衡后的总样本(正+负)进行五折划分,得到每一折的train_index, test_index
            l_dmatix,train_ld_pairs,test_ld_pairs = load_data.L_Dmatix(ld_pairs,train_index,test_index) #调用L_Dmatix得到转化为张量的矩阵,该矩阵仅有这一折的训练集数据中的正样本,返回得到这一折的训练样本和测试样本
            dataset['l_d']=l_dmatix
            # score, lnc_fea, dis_fea = load_data.feature_representation(model, args, dataset)
            score, lnc_fea, dis_fea = load_data.feature_representation(model, args, dataset)
            train_dataset = load_data.new_dataset(lnc_fea, dis_fea, train_ld_pairs)
            test_dataset = load_data.new_dataset(lnc_fea, dis_fea, test_ld_pairs)
            X_train, y_train = train_dataset[:,:-2], train_dataset[:,-2:]
            X_test, y_test = test_dataset[:,:-2], test_dataset[:,-2:]
            print(X_train.shape,X_test.shape)
            # ##随机森林
            # clf = RandomForestClassifier(n_estimators=200,n_jobs=11,max_depth=7)
            # clf.fit(X_train, y_train)
            #
            # y_pred = clf.predict(X_test)
            # # print(score.device)
            # print(y_pred.shape)
            # score1 = score1 + score
            #
            #
            # y_pred = y_pred[:,0]
            # y_prob = clf.predict_proba(X_test)
            # y_prob = y_prob[1][:,0]
            # ##

            # ### xgboost
            clf = XGBClassifier(n_estimators=100, max_depth=7, n_jobs=11)
            clf.fit(X_train, y_train[:, 0])  # Ensure we're using the correct target variable (y_train[:, 0])
            y_pred = clf.predict(X_test)
            print("pred.shape")
            print(y_pred.shape)
            score1 = score1 + score

            # Get the predicted probabilities
            y_prob = clf.predict_proba(X_test)
            y_prob = y_prob[:, 1]  # Get the probability of the positive class

            # Ensure y_test is flattened to 1D if necessary
            y_test_flat = y_test[:, 0] if y_test.ndim > 1 else y_test
            # ###

            # clf = XGBClassifier(n_estimators=100, max_depth=7, learning_rate=0.1, n_jobs=11)
            # clf.fit(X_train, y_train[:, 0])  # XGBoost 需要一维的 y_train
            #
            # # 预测类别
            # y_pred = clf.predict(X_test)  # y_pred 是一维数组
            #
            # # 预测概率
            # y_prob = clf.predict_proba(X_test)[:, 1]  # 获取正类的概率

            # ###adaboost
            # 使用 AdaBoost 分类器，使用决策树作为弱分类器
            # base_clf = DecisionTreeClassifier()
            # clf = AdaBoostClassifier(base_estimator=base_clf, n_estimators=7, learning_rate=1)
            # clf.fit(X_train, y_train[:, 0])
            # y_pred = clf.predict(X_test)
            # print(y_pred.shape)
            # score1 = score1 + score
            #
            # y_prob = clf.predict_proba(X_test)
            # y_prob = y_prob[:, 1]
            # y_test_flat = y_test[:, 0] if y_test.ndim > 1 else y_test
            # ####

            ###svm
            #使用 SVM 作为分类器，使用线性核
            # clf = svm.SVC(kernel='linear', probability=True)
            # clf.fit(X_train, y_train[:, 0])
            # y_pred = clf.predict(X_test)
            # print(y_pred.shape)
            # score1 = score1 + score
            # y_pred = y_pred
            # y_prob = clf.predict_proba(X_test)[:, 1]
            ####

            ####GB
            # clf = GradientBoostingClassifier(n_estimators=100, max_depth=7, learning_rate=0.1)  # 你可以根据需要调节这些超参数
            # clf.fit(X_train, y_train[:, 0])
            # y_pred = clf.predict(X_test)
            # print(y_pred.shape)
            # score1 = score1 + score
            # y_prob = clf.predict_proba(X_test)
            # y_prob = y_prob[:, 1]
            # y_test_flat = y_test[:, 0] if y_test.ndim > 1 else y_test
            ####

            tp, fp, tn, fn, acc, prec, sens, f1_score, MCC, AUC,AUPRC = evaluation_scores.calculate_performace(len(y_pred), y_pred, y_prob, y_test[:,0]) 
            print('RF: \n  Acc = \t', acc, '\n  prec = \t', prec, '\n  sens = \t', sens, '\n  f1_score = \t', f1_score, '\n  MCC = \t', MCC, '\n  AUC = \t', AUC,'\n  AUPRC = \t', AUPRC)
            f.write('RF: \t  tp = \t'+ str(tp) + '\t fp = \t'+ str(fp) + '\t tn = \t'+ str(tn)+ '\t fn = \t'+ str(fn)+'\t  Acc = \t'+ str(acc)+'\t  prec = \t'+ str(prec)+ '\t  sens = \t'+str(sens)+'\t  f1_score = \t'+str(f1_score)+ '\t  MCC = \t'+str(MCC)+'\t  AUC = \t'+ str(AUC)+'\t  AUPRC = \t'+ str(AUPRC)+'\n')
            ave_acc += acc
            ave_prec += prec
            ave_sens += sens
            ave_f1_score += f1_score
            ave_mcc += MCC
            ave_auc += AUC
            ave_auprc += AUPRC

            #每一这roc和aupr准备
            fpr, tpr, _ = roc_curve(y_test[:, 0], y_prob)
            if len(fpr) > 0 and len(tpr) > 0:
                # 进行插值并保存到tprs_list
                tprs_list.append(interp(mean_fpr, fpr, tpr))
                tprs_list[-1][0] = 0.0  # 强制tpr的第一个值为0
            precision, recall, _ = precision_recall_curve(y_test[:, 0], y_prob)
            if len(precision) > 0 and len(recall) > 0:
                precisions_list.append(np.interp(mean_recall, recall[::-1], precision[::-1]))
                average_precisions.append(average_precision_score(y_test[:, 0], y_prob))

            # 计算AUC并保存
            auc_score = auc(fpr, tpr)
            aucs.append(auc_score)

        torch.save(model.state_dict(), 'model.pth')
        print("success")
        # Colorectal Neoplasms,Crohn Disease案例研究

        ave_acc /= n_fold
        ave_prec /= n_fold
        ave_sens /= n_fold
        ave_f1_score /= n_fold
        ave_mcc /= n_fold
        ave_auc /= n_fold
        ave_auprc /= n_fold
        print('Final: \t  tp = \t'+ str(tp) + '\t fp = \t'+ str(fp) + '\t tn = \t'+ str(tn)+ '\t fn = \t'+ str(fn)+'\t  Acc = \t'+ str(ave_acc)+'\t  prec = \t'+ str(ave_prec)+ '\t  sens = \t'+str(ave_sens)+'\t  f1_score = \t'+str(ave_f1_score)+ '\t  MCC = \t'+str(ave_mcc)+'\t  AUC = \t'+ str(ave_auc)+'\t  AUPRC = \t'+ str(ave_auprc)+'\n')
        f.write('Final: \t  tp = \t'+ str(tp) + '\t fp = \t'+ str(fp) + '\t tn = \t'+ str(tn)+ '\t fn = \t'+ str(fn)+'\t  Acc = \t'+ str(ave_acc)+'\t  prec = \t'+ str(ave_prec)+ '\t  sens = \t'+str(ave_sens)+'\t  f1_score = \t'+str(ave_f1_score)+ '\t  MCC = \t'+str(ave_mcc)+'\t  AUC = \t'+ str(ave_auc)+'\t  AUPRC = \t'+ str(ave_auprc)+'\n')

        # 绘制ROC曲线
        for i, tpr in enumerate(tprs_list):
            axs[0].plot(mean_fpr, tpr, alpha=0.5, linestyle='-', linewidth=1,
                        label=f'Fold {i + 1} (AUC = {aucs[i]:.5f})')
        if tprs_list:
            mean_tpr = np.mean(tprs_list, axis=0)
            # mean_auc = auc(mean_fpr, mean_tpr)
            mean_auc = np.mean(aucs)
            axs[0].plot(mean_fpr, mean_tpr, color='b', label=f'Mean ROC (AUC = {mean_auc:.4f})', linewidth=2.5,
                        linestyle='-')
        axs[0].plot([0, 1], [0, 1], linestyle='--', color='gray', alpha=0.7)
        axs[0].set_title('ROC Curve', fontsize=14, fontweight='bold')
        axs[0].set_xlabel('False Positive Rate (FPR)', fontsize=12)
        axs[0].set_ylabel('True Positive Rate (TPR)', fontsize=12)
        axs[0].legend(loc='lower right')
        axs[0].grid(True, linestyle='--', alpha=0.5)

        # Plot PR curves
        fin_score = score/5
        fin_score_final = torch.sigmoid(fin_score)
        np.savetxt('output.csv', fin_score_final.cpu() , delimiter=',', fmt='%d')
        for i, precision in enumerate(precisions_list):
            axs[1].plot(mean_recall, precision, alpha=0.5, linestyle='-', linewidth=1,
                        label=f'Fold {i + 1} (AP = {average_precisions[i]:.5f})')
        if precisions_list:
            mean_precision = np.mean(precisions_list, axis=0)
            mean_ap = np.mean(average_precisions)
            axs[1].plot(mean_recall, mean_precision, color='b', label=f'Mean PR (AP = {mean_ap:.4f})', linewidth=2.5,
                        linestyle='-')

        # Add a baseline horizontal line for PR curve
        # axs[1].axhline(y=0.5, color='gray', linestyle='--', alpha=0.7, label='Baseline')

        axs[1].set_title('PR Curve', fontsize=14, fontweight='bold')
        axs[1].set_xlabel('Recall', fontsize=12)
        axs[1].set_ylabel('Precision', fontsize=12)
        axs[1].legend(loc='lower left')
        axs[1].grid(True, linestyle='--', alpha=0.5)
        plt.tight_layout()
        plt.show()


# def case_study_LDA(n_fold):
#     args = parameter_parser()
#     dataset, ld_pairs = load_data.dataset(args)
#
#     kf = KFold(n_splits=n_fold, shuffle=True)
#     model = MTBLDA(args)
#
#     #加载训练好的模型参数
#     model.load_state_dict(torch.load('model.pth'))
#
#     case_study_pred_matrix = np.zeros((240, 412))
#
#     localtime = time.asctime(time.localtime(time.time()))
#     with open('E:/project/AACODE/ceshi/result/GraphCDA-100--5fold.txt', 'a') as f:
#         f.write('time:\t' + str(localtime) + "\n")
#
#         for train_index, test_index in kf.split(ld_pairs):  # 将平衡后的总样本(正+负)进行五折划分,得到每一折的train_index, test_index
#             l_dmatix, train_ld_pairs, test_ld_pairs = load_data.L_Dmatix(ld_pairs, train_index,
#                                                                          test_index)  # 调用L_Dmatix得到转化为张量的矩阵,该矩阵仅有这一折的训练集数据中的正样本,返回得到这一折的训练样本和测试样本
#             dataset['l_d'] = l_dmatix
#             # score, lnc_fea, dis_fea = load_data.feature_representation(model, args, dataset)
#             score, lnc_fea, dis_fea = load_data.feature_representation(model, args, dataset)
#             train_dataset = load_data.new_dataset(lnc_fea, dis_fea, train_ld_pairs)
#             test_dataset = load_data.new_dataset(lnc_fea, dis_fea, test_ld_pairs)
#             X_train, y_train = train_dataset[:, :-2], train_dataset[:, -2:]
#             X_test, y_test = test_dataset[:, :-2], test_dataset[:, -2:]
#             print(X_train.shape, X_test.shape)
#
#             # ### xgboost
#             clf = XGBClassifier(n_estimators=100, max_depth=7, n_jobs=11)
#             clf.fit(X_train, y_train[:, 0])  # Ensure we're using the correct target variable (y_train[:, 0])
#             y_pred = clf.predict(X_test)
#             print("pred.shape")
#             print(y_pred.shape)
#             # Get the predicted probabilities
#             y_prob = clf.predict_proba(X_test)
#             y_prob = y_prob[:, 1]  # Get the probability of the positive class
#
#             for idx, test_idx in enumerate(test_index):
#                 # test_index的值应该是相应的行和列位置
#                 # 假设test_index是行-列的坐标元组
#                 lnc_idx, disease_idx = ld_pairs[test_idx][0], ld_pairs[test_idx][1]
#
#                 # 将y_pred的值保存到相应位置
#                 case_study_pred_matrix[lnc_idx, disease_idx] = y_prob[idx]
#
#         pred_df = pd.DataFrame(case_study_pred_matrix)
#         pred_df.to_csv('pred.csv', index=False)  # 保存为 CSV 文件


if __name__ == "__main__":
    
    n_fold = 5
    for i in range(1):
        LDA(n_fold)
        #case_study_LDA(n_fold)
