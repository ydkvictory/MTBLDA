import argparse


def parameter_parser():

    parser = argparse.ArgumentParser(description="Run GraphMDA.")

    parser.add_argument("--dataset_path",
                        nargs="?",
                        default="E:/project/AACODE/ceshi/dataset1",
                        help="Training datasets.")

    parser.add_argument("--epoch",
                        type=int,
                        default=300,
                        help="Number of training epochs. Default is 400.")

    parser.add_argument("--gcn-layers",
                        type=int,
                        default=3,
                        help="Number of Graph Convolutional Layers. Default is 2.")

    parser.add_argument("--out-channels",
                        type=int,
                        default=384,
                        help="out-channels of cnn. Default is 256.")

    parser.add_argument("--out-channels_cnn",
                        type=int,
                        default=512,
                        help="out-channels of cnn. Default is 256.")

    parser.add_argument("--LncRNA-number",
                        type=int,
                        default=240,
                        help="lncRNA number. dataset1=240,dataset2=447,dataset4=665.")

    parser.add_argument("--flnc",
                        type=int,
                        default=512,
                        help="lncRNA feature dimensions. Default is 128.")

    parser.add_argument("--disease-number",
                        type=int,
                        default=412,
                        help="disease number. dataset1=412,dataset2=218,dataset4=316.")

    parser.add_argument("--fdis",
                        type=int,
                        default=512,
                        help="disease feature dimensions. Default is 128.")

    parser.add_argument("--fhereto",
                        type=int,
                        default=512,
                        help="disease feature dimensions. Default is 128.")

    parser.add_argument("--d_input",
                        type=int,
                        default=512,
                        help="disease feature dimensions. Default is 128.")


    parser.add_argument("--d_model",
                        type=int,
                        default=512,
                        help="disease feature dimensions. Default is 128.")

    parser.add_argument("--n_heads",
                        type=int,
                        default=1,
                        help="disease feature dimensions. Default is 128.")

    parser.add_argument("--e_layers",
                        type=int,
                        default=2,
                        help="disease feature dimensions. Default is 128.")

    parser.add_argument("--d_ff",
                        type=float,
                        default=0.3,
                        help="disease feature dimensions. Default is 128.")

    parser.add_argument("--pos_emb",
                        type=bool,
                        default=False,
                        help="disease feature dimensions. Default is 128.")

    parser.add_argument("--value_linear",
                        type=bool,
                        default=True,
                        help="disease feature dimensions. Default is 128.")

    parser.add_argument("--value_sqrt",
                        type=bool,
                        default=False,
                        help="disease feature dimensions. Default is 128.")

    parser.add_argument("--add",
                        type=bool,
                        default=True,
                        help="disease feature dimensions. Default is 128.")

    parser.add_argument("--norm",
                        type=bool,
                        default=True,
                        help="disease feature dimensions. Default is 128.")

    parser.add_argument("--ff",
                        type=bool,
                        default=True,
                        help="disease feature dimensions. Default is 128.")

    parser.add_argument("--dropout",
                        type=float,
                        default=0.05,
                        help="disease feature dimensions. Default is 128.")

    parser.add_argument("--k_neig",
                        type=int,
                        default=3,
                        help="disease feature dimensions. Default is 3.")

    parser.add_argument("--lncRNA_view",
                        type=int,
                        default=3,
                        help="disease feature dimensions. Default is 3.")

    parser.add_argument("--disease_view",
                        type=int,
                        default=3,
                        help="disease feature dimensions. Default is 3.")

    return parser.parse_args()