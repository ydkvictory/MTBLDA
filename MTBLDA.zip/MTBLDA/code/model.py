import torch
from torch import nn
from torch_geometric.nn import GCNConv
from Layers import MultiLDAformer,SKFusion
from torch_geometric.nn import GATConv

torch.backends.cudnn.enabled = False

class MTBLDA(nn.Module):
    def __init__(self, args):
        """
        :param args: Arguments object.
        """
        super(MTBLDA, self).__init__()
        self.args = args

        # self.leaky_relu = torch.nn.LeakyReLU(negative_slope=0.01)

        self.LncRNA_feedForward = nn.Sequential(
            nn.LayerNorm(self.args.LncRNA_number),
            nn.Linear(self.args.LncRNA_number, self.args.flnc),
            nn.ReLU()
        )
        self.disease_feedForward = nn.Sequential(
            nn.LayerNorm(self.args.disease_number),
            nn.Linear(self.args.disease_number, self.args.fdis),
            nn.ReLU()
        )



        self.gat_hereto_1 = GATConv(self.args.fhereto, self.args.fhereto, heads=2, concat=False, edge_dim=1)
        self.gat_hereto_2 = GATConv(self.args.fhereto, self.args.fhereto, heads=2, concat=False, edge_dim=1)


        self.gcn_hereto = GCNConv(self.args.fhereto, self.args.fhereto)


        self.gcn_LncRNA = GCNConv(self.args.flnc, self.args.flnc)
        self.gcn_disease = GCNConv(self.args.fdis, self.args.fdis)



        self.MultiLDAformer_LncRNA = MultiLDAformer(d_input=self.args.d_input,d_model=self.args.d_model,n_heads=self.args.n_heads,e_layers=self.args.e_layers,d_ff=self.args.d_ff,pos_emb=self.args.pos_emb,
                                                   value_linear=self.args.value_linear,value_sqrt=self.args.value_sqrt,add=self.args.add,norm=self.args.norm,ff=self.args.ff,dropout=self.args.dropout)
        self.MultiLDAformer_disease = MultiLDAformer(d_input=self.args.d_input,d_model=self.args.d_model,n_heads=self.args.n_heads,e_layers=self.args.e_layers,d_ff=self.args.d_ff,pos_emb=self.args.pos_emb,
                                                   value_linear=self.args.value_linear,value_sqrt=self.args.value_sqrt,add=self.args.add,norm=self.args.norm,ff=self.args.ff,dropout=self.args.dropout)

        self.globalAvgPool_x = nn.AvgPool2d((self.args.flnc, self.args.LncRNA_number), (1, 1))
        self.globalAvgPool_y = nn.AvgPool2d((self.args.fdis, self.args.disease_number), (1, 1))

        self.fc1_x = nn.Linear(in_features=self.args.lncRNA_view ,out_features=5 * self.args.lncRNA_view )
        self.fc2_x = nn.Linear(in_features=5 * self.args.lncRNA_view ,out_features=self.args.lncRNA_view )

        self.fc1_y = nn.Linear(in_features=self.args.disease_view ,out_features=5 * self.args.disease_view )
        self.fc2_y = nn.Linear(in_features=5 * self.args.disease_view ,out_features=self.args.disease_view )

        self.cnn_lnc = nn.Conv2d(in_channels=self.args.gcn_layers,out_channels=self.args.out_channels_cnn ,kernel_size=(self.args.d_model, 1),stride=1,bias=True)
        self.cnn_dis = nn.Conv2d(in_channels=self.args.gcn_layers,out_channels=self.args.out_channels_cnn,kernel_size=(self.args.d_model, 1),stride=1,bias=True)

        self.sigmoidx = nn.Sigmoid()
        self.sigmoidy = nn.Sigmoid()

        self.SKFusion_lnc_1 = SKFusion(1)
        self.SKFusion_lnc_2 = SKFusion(1)
        self.SKFusion_dis_1 = SKFusion(1)
        self.SKFusion_dis_2 = SKFusion(1)




    def forward(self, data):
        #随机生成mirna和disease用于提取结构和异构拓扑的初始特征
        x = torch.randn(self.args.LncRNA_number + self.args.disease_number, self.args.fhereto)
        x_randn_LncRNA = x[:self.args.LncRNA_number].cuda()
        x_randn_disease = x[self.args.LncRNA_number:].cuda()

        #获得mirna和disease基于已知关联矩阵的初始特征
        x_ori_LncRNA = self.LncRNA_feedForward(data['lnc_ori'].cuda()).unsqueeze(0)
        x_ori_disease = self.disease_feedForward((data['dis_ori'].t()).cuda()).unsqueeze(0)

        #m-d异构图通过两层gat一层GCN提取m和d的拓扑特征
        x_hereto_att1 = torch.relu(self.gat_hereto_1(x.cuda(), data['ld']['edges'].cuda(),data['ld']['data_matrix'][data['ld']['edges'][0], data['ld']['edges'][1]].cuda()))
        x_hereto_att2 = torch.relu(self.gat_hereto_2(x_hereto_att1, data['ld']['edges'].cuda(), data['ld']['data_matrix'][data['ld']['edges'][0], data['ld']['edges'][1]].cuda()))
        x_hereto = torch.relu(self.gcn_hereto(x_hereto_att2, data['ld']['edges'].cuda(), data['ld']['data_matrix'][data['ld']['edges'][0], data['ld']['edges'][1]].cuda()))
        x_hereto_LncRNA = x_hereto[:self.args.LncRNA_number].unsqueeze(0)
        x_hereto_disease = x_hereto[self.args.LncRNA_number:].unsqueeze(0)

        #对于m和d的同构图,通过一层GCN提取结构特征

        x_struct_LncRNA = torch.relu(self.gcn_LncRNA(x_randn_LncRNA.cuda(), data['ll']['edges'].cuda(), data['ll']['data_matrix'][data['ll']['edges'][0], data['ll']['edges'][1]].cuda())).unsqueeze(0)
        x_struct_disease = torch.relu(self.gcn_disease(x_randn_disease.cuda(), data['dd']['edges'].cuda(), data['dd']['data_matrix'][data['dd']['edges'][0], data['dd']['edges'][1]].cuda())).unsqueeze(0)

        #####主体模型
        ##初始 特征,异构拓扑特征,同构结构特征两两送入transformer进行融合
        LncRNA_fea1,LncRNA_fea2,LncRNA_fea3= self.MultiLDAformer_LncRNA(x_ori_LncRNA, x_hereto_LncRNA, x_struct_LncRNA)
        disease_fea1, disease_fea2 ,disease_fea3 = self.MultiLDAformer_disease(x_ori_disease, x_hereto_disease, x_struct_disease)

        # 使用SKFusion融合
        x_1 = self.SKFusion_lnc_1([LncRNA_fea1.unsqueeze(0), LncRNA_fea2.unsqueeze(0)])
        x = self.SKFusion_lnc_2([x_1, LncRNA_fea3.unsqueeze(0)]).squeeze()

        y_1 = self.SKFusion_dis_1([disease_fea1.unsqueeze(0), disease_fea2.unsqueeze(0)])
        y = self.SKFusion_dis_2([y_1, disease_fea3.unsqueeze(0)]).squeeze()
        ######

        # ##变体MTBLDA-noori
        # #(消融实验两特征)送入transformer进行融合
        # LncRNA_fea1, LncRNA_fea2 = self.MultiLDAformer_LncRNA(x_hereto_LncRNA,
        #                                                       x_struct_LncRNA)
        # disease_fea1, disease_fea2 = self.MultiLDAformer_disease(x_hereto_disease,
        #                                                          x_struct_disease)
        #
        # #使用SKFusion融合
        # x = self.SKFusion_lnc_1([LncRNA_fea1.unsqueeze(0), LncRNA_fea2.unsqueeze(0)]).squeeze()
        #
        #
        # y = self.SKFusion_dis_1([disease_fea1.unsqueeze(0), disease_fea2.unsqueeze(0)]).squeeze()
        # ###

        # ##变体MTBLDA-nohereto
        # #(消融实验两特征)送入transformer进行融合
        # LncRNA_fea1, LncRNA_fea2 = self.MultiLDAformer_LncRNA(x_ori_LncRNA,
        #                                                       x_struct_LncRNA)
        # disease_fea1, disease_fea2 = self.MultiLDAformer_disease(x_ori_disease,
        #                                                          x_struct_disease)
        #
        # #使用SKFusion融合
        # x = self.SKFusion_lnc_1([LncRNA_fea1.unsqueeze(0), LncRNA_fea2.unsqueeze(0)]).squeeze()
        #
        #
        # y = self.SKFusion_dis_1([disease_fea1.unsqueeze(0), disease_fea2.unsqueeze(0)]).squeeze()
        # ###

        # ##变体MTBLDA-nohomo
        # #(消融实验两特征)送入transformer进行融合
        # LncRNA_fea1, LncRNA_fea2 = self.MultiLDAformer_LncRNA(x_ori_LncRNA,
        #                                                       x_hereto_LncRNA)
        # disease_fea1, disease_fea2 = self.MultiLDAformer_disease(x_ori_disease,
        #                                                          x_hereto_disease)
        #
        # #使用SKFusion融合
        # x = self.SKFusion_lnc_1([LncRNA_fea1.unsqueeze(0), LncRNA_fea2.unsqueeze(0)]).squeeze()
        #
        #
        # y = self.SKFusion_dis_1([disease_fea1.unsqueeze(0), disease_fea2.unsqueeze(0)]).squeeze()
        # ###


        # ###变体MTBLDA-nobert
        # x_1 = self.SKFusion_lnc_1([x_ori_LncRNA.unsqueeze(0), x_hereto_LncRNA.unsqueeze(0)])
        # x = self.SKFusion_lnc_2([x_1, x_struct_LncRNA.unsqueeze(0)]).squeeze()
        #
        # y_1 = self.SKFusion_dis_1([x_ori_disease.unsqueeze(0), x_hereto_disease.unsqueeze(0)])
        # y = self.SKFusion_dis_2([y_1, x_struct_disease.unsqueeze(0)]).squeeze()

        # # 使用SKFusion融合
        # x_1 = self.SKFusion_lnc_1([LncRNA_fea1.unsqueeze(0), LncRNA_fea2.unsqueeze(0)])
        # x = self.SKFusion_lnc_2([x_1, LncRNA_fea3.unsqueeze(0)]).squeeze()
        #
        # y_1 = self.SKFusion_dis_1([disease_fea1.unsqueeze(0), disease_fea2.unsqueeze(0)])
        # y = self.SKFusion_dis_2([y_1, disease_fea3.unsqueeze(0)]).squeeze()
        # ###

        # ###变体MTBLDA-noskf
        # x = torch.cat((LncRNA_fea1, LncRNA_fea2, LncRNA_fea3), dim=2).squeeze()
        # y = torch.cat((disease_fea1, disease_fea2 ,disease_fea3), dim=2).squeeze()
        # ###


        return x.mm(y.t()),x,y














